from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import yt_dlp

app = Flask(__name__, static_folder="static", template_folder=".")
CORS(app)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/fetch', methods=['POST'])
def fetch():
    url = request.form.get('url')
    if not url:
        return jsonify({'error': 'No URL provided'}), 400

    ydl_opts = {
        'quiet': True,
        'skip_download': True,
        'forcejson': True,
        'proxy': '',
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            formats = []
            for f in info.get('formats', []):
                if f.get('url') and f.get('filesize'):
                    formats.append({
                        'format_note': f.get('format_note'),
                        'ext': f.get('ext'),
                        'filesize': f.get('filesize'),
                        'proxy_url': f.get('url'),
                    })
            return jsonify({
                'title': info.get('title'),
                'duration': info.get('duration_string', ''),
                'thumbnail': info.get('thumbnail'),
                'formats': formats
            })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
